package prachi.com.farmmaintenance;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class farmMaintenance extends AppCompatActivity {

    TextView mFan;
    TextView mSprinkler;
    String val;
    String val1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farm_maintenance);

        mFan = (TextView) findViewById(R.id.fan);


        mSprinkler = (TextView) findViewById(R.id.sprinkler);

        mFan.setText("FAN ON");
        mSprinkler.setText("FAN OFF");

        displayVlues();

    }

    public void displayVlues(){

        val = MyReceiver.forTemp;
        val1 = MyReceiver2.forTnS;


        if(val.equals("ON")){
            mFan.setText("FAN ON");
        }else {
            mFan.setText("FAN OFF");
        }


        if(val1.equals("ON")){
            mFan.setText("FAN ON");
            mSprinkler.setText("SPRINKLER ON");
        }
        else {
            mSprinkler.setText("SPRINKLER OFF");
            mSprinkler.setText("SPRINKLER OFF");
        }
    }


}

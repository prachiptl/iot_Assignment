package prachi.com.farmmaintenance;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyReceiver extends BroadcastReceiver {
    public MyReceiver() {
    }

    private static final String tag = "TestReceiver";
    public static String forTemp = "OFF";


    @Override
    public void onReceive(Context context, Intent intent1) {
        Log.d(tag, "after send broadcast from main menu");
        forTemp = intent1.getStringExtra("message");
        Log.d(tag, "Hoo gaya kam");
       // throw new UnsupportedOperationException("Not yet implemented");

    }


}

package prachi.com.farmmaintenance;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyReceiver2 extends BroadcastReceiver {
    public MyReceiver2() {
    }
    private static final String tag = "TestReceiver";
    public static String forTnS = "ON";

    @Override
    public void onReceive(Context context, Intent intent2) {

        Log.d(tag, "after send broadcast from main menu");
        forTnS = intent2.getStringExtra("message");
        Log.d(tag, "Hoo gaya kam");
        //throw new UnsupportedOperationException("Not yet implemented");
    }
}

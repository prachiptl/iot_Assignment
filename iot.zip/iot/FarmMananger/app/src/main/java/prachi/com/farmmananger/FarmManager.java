package prachi.com.farmmananger;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class FarmManager extends AppCompatActivity {

    TextView mWriteIt;
    Button mDisplayValues;
    Button mTurnFan;
    Button mTurnFanSprinkler;
    public static final String tag="Testsender";
    private boolean isOn = false;
    private boolean isFSOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farm_manager);

        mWriteIt = (TextView) findViewById(R.id.writeHere);
        mDisplayValues = (Button) findViewById(R.id.diaplayValues);
        mTurnFan = (Button) findViewById(R.id.turnFan);
        mTurnFan.setText("TURN FAN ON");
        mTurnFanSprinkler = (Button) findViewById(R.id.turnFanSprinkler);
        mTurnFanSprinkler.setText("TURN FAN & SPRINKLER ON");

        mDisplayValues.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayValues();
            }
        });

        mTurnFan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isOn = true;

                if(isOn) {
                    mTurnFan.setText("TURN FAN OFF");

                    Intent intent1 = new Intent();
                    intent1.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                    intent1.setAction("prachi.com.farmmananger");
                    intent1.putExtra("message", "ON");
                    sendBroadcast(intent1);

                    Log.d(tag, "after send broadcast fOR FAN");

                }
                else {
                    mTurnFan.setText("TURN FAN OFF");
                }
            }
        });

        mTurnFanSprinkler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFSOn = true;
                if(isFSOn){

                    mTurnFanSprinkler.setText("TURN FAN & SPRINKLER OFF");
                    Intent intent2 = new Intent();
                    intent2.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                    intent2.setAction("prachi.com.farmmananger");
                    intent2.putExtra("message", "ON");
                    sendBroadcast(intent2);
                    Log.d(tag, "after send broadcast fOr FAN AND SPRINKLER");
                    Toast.makeText(FarmManager.this, "The signals are sent for fan and sprinkler", Toast.LENGTH_LONG);

                }
            }
        });

    }

    public void displayValues(){
        mWriteIt.setText("Temperature is: " + MyReceiver.temp + " And Humidity is:" + MyReceiver.humid);

    }
}

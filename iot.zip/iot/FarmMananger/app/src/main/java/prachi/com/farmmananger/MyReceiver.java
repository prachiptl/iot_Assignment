package prachi.com.farmmananger;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyReceiver extends BroadcastReceiver {
    public MyReceiver() {
    }
    static String temp;
    static String humid;
    private static final String tag = "TestReceiver";
    @Override
    public void onReceive(Context context, Intent intent) {

        Log.d(tag, "after send broadcast from main menu");
        temp = intent.getStringExtra("Temperature");
        humid = intent.getStringExtra("Humidity");
       // throw new UnsupportedOperationException("Not yet implemented");
        Log.d(tag, temp);
        Log.d(tag, humid);

    }
}

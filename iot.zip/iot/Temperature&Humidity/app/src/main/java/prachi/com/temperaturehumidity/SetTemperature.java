package prachi.com.temperaturehumidity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SetTemperature extends AppCompatActivity {

    EditText mTemp;
    EditText mHumid;
    Button mSet;
    Button mCancel;
    public static final String tag="Testsender";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_temperature);

        mTemp = (EditText) findViewById(R.id.textForTemperature);
        mHumid = (EditText)findViewById(R.id.textForHumidity);
        mSet = (Button)findViewById(R.id.setButton);
        mCancel = (Button)findViewById(R.id.cancelButton);

        mSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                intent.setAction("prachi.com.temperaturehumidity");
                intent.putExtra("Temperature", mTemp.getText().toString());
                intent.putExtra("Humidity", mHumid.getText().toString());
                sendBroadcast(intent);
                Log.d(tag, "after send broadcast from main menu");
                Toast.makeText(SetTemperature.this,"The values are send",Toast.LENGTH_LONG);
            }
        });

        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
